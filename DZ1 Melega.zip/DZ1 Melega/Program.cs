﻿int summa = 0;
int sum = 0;
int x1 = 0;
int y1 = 0;
for (int x = 0; x < 10; x++)
{
    for(int y = 0; y < 10; y++)
    {
        if(6 * x + 6 * y <= 36 && 4 * x + 2 * y <= 20 && 4 * x + 8 * y <= 40)
        {
            sum = 12 * x + 15 * y;
            if (sum > summa)
            {
                summa = sum; x1 = x; y1 = y;
            }
        }
    }    
}
Console.WriteLine($"Максимальная прибыль {summa}");
Console.WriteLine($"P1 = {x1} P2 = {y1}");
Console.ReadKey();


